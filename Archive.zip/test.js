var AWS = require("aws-sdk");console.log(AWS.EC2.apiVersions)
